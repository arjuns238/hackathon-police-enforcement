"""Durable observation of provider calls; never changes model requests or replies."""
from __future__ import annotations

import json
import os
import traceback
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path


def install_model_capture(game) -> None:
    """Capture each API attempt, including retries, in this single-game process.

    Completed episodes keep their existing checkpoints. This extra journal saves
    requests before sending and full replies before the retry/parser path sees
    them, so dropped or malformed replies are retained too.
    """
    from experiments import agents

    if getattr(game, "_raw_capture_installed", False):
        return
    if getattr(agents.completion, "_peer_check_capture", False):
        raise RuntimeError("A different game already owns model capture in this process")
    path = Path(game.out) / "raw_model_calls.jsonl"
    secrets = [os.environ.get(name, "") for name in
               ("QWEN_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY")]
    secrets = sorted({value for value in secrets if value}, key=len, reverse=True)
    context = {"invocation_id": game.invocation_id}

    def jsonable(value):
        if hasattr(value, "model_dump"):
            return value.model_dump()
        return str(value)

    def append(record):
        record = {"capture_version": 1, "recorded_at": datetime.now(timezone.utc).isoformat(),
                  **context, **record}
        try:
            payload = json.dumps(record, ensure_ascii=False, default=jsonable)
            # Redact only known credentials, without touching the live objects.
            for secret in secrets:
                payload = payload.replace(secret, "[REDACTED_API_KEY]")
            with path.open("a", encoding="utf-8") as handle:
                handle.write(payload + "\n")
                handle.flush()
                os.fsync(handle.fileno())
        except Exception as exc:
            # A storage failure must stop the game, not become a paid API retry.
            raise SystemExit(f"Cannot persist raw model call journal: {type(exc).__name__}") from exc

    original_recorder = game.recorder

    def recorder(ep, actor, phase, round_idx, attempt, sink):
        context.update(episode=ep + 1, actor=actor, phase=phase,
                       round=round_idx + 1 if round_idx is not None else None,
                       attempt=attempt)
        return original_recorder(ep, actor, phase, round_idx, attempt, sink)

    original_completion = agents.completion

    def completion(*args, **kwargs):
        call_id = uuid.uuid4().hex
        append({"event": "request", "call_id": call_id, "args": args, "kwargs": kwargs})
        try:
            response = original_completion(*args, **kwargs)
        except Exception as exc:
            append({"event": "error", "call_id": call_id, "error_type": type(exc).__name__,
                    "error": str(exc), "traceback": traceback.format_exc()})
            raise
        append({"event": "response", "call_id": call_id, "response": response})
        return response

    append({"event": "capture_started", "config": asdict(game.cfg)})
    completion._peer_check_capture = True
    agents.completion = completion
    game.recorder = recorder
    game._raw_capture_installed = True
