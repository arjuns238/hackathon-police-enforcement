"""Offline checks that durable capture preserves call semantics and failure behavior."""
import json
import os
import sys
import tempfile
import types
import unittest
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from peer_check.capture import install_model_capture


@dataclass
class Config:
    model: str = "stub"


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.agents = types.ModuleType("experiments.agents")
        package = types.ModuleType("experiments")
        package.agents = self.agents
        patcher = patch.dict(sys.modules, {"experiments": package, "experiments.agents": self.agents})
        patcher.start()
        self.addCleanup(patcher.stop)
        self.game = types.SimpleNamespace(out=Path(self.tmp.name), cfg=Config(), invocation_id="test",
                                         recorder=lambda *a: "usage recorder")

    def records(self):
        return [json.loads(line) for line in (self.game.out / "raw_model_calls.jsonl").read_text().splitlines()]

    def test_full_reply_request_identity_metadata_and_redaction(self):
        request = [{"role": "user", "content": "input secret-sentinel"}]
        response = {"choices": [{"message": {"reasoning_content": "thinking", "content": "answer",
                                               "tool_calls": [{"arguments": "nested raw JSON"}]}}]}
        seen = []
        self.agents.completion = lambda **kw: (seen.append(kw) or response)
        with patch.dict(os.environ, {"QWEN_API_KEY": "secret-sentinel"}):
            install_model_capture(self.game)
        self.assertEqual(self.game.recorder(0, "alice", "communication", 0, 2, []), "usage recorder")
        result = self.agents.completion(messages=request, temperature=1.0)
        self.assertIs(result, response)
        self.assertIs(seen[0]["messages"], request)
        self.assertEqual(request[0]["content"], "input secret-sentinel")
        rows = self.records()
        self.assertEqual([r["event"] for r in rows], ["capture_started", "request", "response"])
        self.assertEqual(rows[1]["call_id"], rows[2]["call_id"])
        self.assertEqual(rows[2]["response"], response)
        self.assertEqual((rows[1]["episode"], rows[1]["actor"], rows[1]["round"]), (1, "alice", 1))
        self.assertIn("[REDACTED_API_KEY]", rows[1]["kwargs"]["messages"][0]["content"])

    def test_errors_are_recorded_and_original_exception_is_preserved(self):
        original = ValueError("provider error")
        def fail(**kw):
            raise original
        self.agents.completion = fail
        install_model_capture(self.game)
        with self.assertRaises(ValueError) as caught:
            self.agents.completion(model="stub")
        self.assertIs(caught.exception, original)
        self.assertEqual(self.records()[-1]["event"], "error")
        self.assertEqual(self.records()[-1]["error_type"], "ValueError")

    def test_storage_failure_after_response_stops_without_an_extra_provider_call(self):
        calls = []
        self.agents.completion = lambda **kw: (calls.append(kw) or {"ok": True})
        install_model_capture(self.game)
        real_fsync = os.fsync
        syncs = []
        def fail_on_response(fd):
            syncs.append(fd)
            if len(syncs) == 2:
                raise OSError("disk full")
            real_fsync(fd)
        with patch("peer_check.capture.os.fsync", side_effect=fail_on_response):
            with self.assertRaises(SystemExit):
                self.agents.completion(model="stub")
        self.assertEqual(len(calls), 1)

    def test_installing_twice_does_not_duplicate_capture(self):
        self.agents.completion = lambda **kw: {"ok": True}
        install_model_capture(self.game)
        install_model_capture(self.game)
        self.agents.completion(model="stub")
        self.assertEqual(len(self.records()), 3)


if __name__ == "__main__":
    unittest.main()
