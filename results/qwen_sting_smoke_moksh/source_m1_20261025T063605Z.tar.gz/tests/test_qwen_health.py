"""Offline checks for the narrow, explicitly approved M1 health classification."""
import importlib.util
import json
import unittest
from copy import deepcopy
from pathlib import Path

spec = importlib.util.spec_from_file_location("qwen_health", Path(__file__).resolve().parents[1] / "scripts/qwen_health.py")
health = importlib.util.module_from_spec(spec)
spec.loader.exec_module(health)


class CorrectedRecipientTests(unittest.TestCase):
    def events(self):
        common = {"actor": "dave", "tool": "send_message", "phase": "communication", "round": 2}
        return [
            {**common, "success": False, "to": "", "content": "Hello Bob", "error": 'to must be "group" or a peer'},
            {**common, "failed_call_raw": json.dumps({"name": "Bob", "content": "Hello Bob"})},
            {**common, "success": True, "to": "bob", "content": "Hello Bob"},
        ]

    def test_recovered_direct_typo_is_reported_not_gated(self):
        self.assertTrue(health.corrected_recipient_error(self.events(), 0))

    def test_unrecovered_error_still_fails(self):
        self.assertFalse(health.corrected_recipient_error(self.events()[:2], 0))

    def test_wrapped_arguments_still_fail(self):
        events = self.events()
        events[1]["failed_call_raw"] = json.dumps({"arguments": {"to": "bob", "content": "Hello Bob"}})
        self.assertFalse(health.corrected_recipient_error(events, 0))

    def test_no_raw_evidence_still_fails(self):
        events = self.events()
        self.assertFalse(health.corrected_recipient_error([events[0], events[2]], 0))

    def test_different_content_not_assumed_corrected(self):
        events = self.events()
        events[2]["content"] = "Different message"
        self.assertFalse(health.corrected_recipient_error(events, 0))

    def test_other_round_actor_or_phase_cannot_supply_correction(self):
        for key, value in (("round", 3), ("actor", "alice"), ("phase", "verdict")):
            events = deepcopy(self.events())
            events[2][key] = value
            self.assertFalse(health.corrected_recipient_error(events, 0))

    def test_valid_recipient_in_raw_args_indicates_a_different_problem(self):
        events = self.events()
        events[1]["failed_call_raw"] = json.dumps({"to": "bob", "content": "Hello Bob"})
        self.assertFalse(health.corrected_recipient_error(events, 0))


if __name__ == "__main__":
    unittest.main()
